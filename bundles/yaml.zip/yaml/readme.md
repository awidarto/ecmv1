# Yaml for Laravel 3.x

I had a probject where I needed to parse YAML.  I made this quick package using [SPYC](http://code.google.com/p/spyc/) which seems to do the trick.

## Install

Normal bundle install, but be sure to update the vendor submodule:

```
$ cd bundles/yaml
$ git submodule update --init
```

## Usage

```
$parsed = Yaml::from_file($path)->to_array();
```