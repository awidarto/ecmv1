<?php

Autoloader::map(array(
    'Yaml' => __DIR__.'/libraries/yaml.php',
));